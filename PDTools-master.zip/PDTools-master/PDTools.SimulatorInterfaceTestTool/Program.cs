using System;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
//using System.Globalization;
//using System.Device.Gpio;
//using System.Device.Spi;
//using MAX7219Sharp;
//using Iot.Device.ServoMotor;
//using System.Device.Pwm;
using System.IO;
using System.Numerics;

using PDTools.SimulatorInterface;



namespace PDTools.SimulatorInterfaceTestTool
{
    internal class Program
    {
        private static bool _showUnknown = false;

        static async Task Main(string[] args)
        {
            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;

            /* Mostly a test sample for using the Simulator Interface library */

            Console.WriteLine("Simulator Interface GT7/GTSport/GT6 - Nenkai#9075");
            Console.WriteLine();

            if (args.Length == 0)
            {
                Console.WriteLine("Usage: SimulatorInterface.exe <IP address of PS4/PS5> ('--gtsport' for GT Sport support, --gt6 for GT6 support, optional: '--debug' to show unknown values)");
                return;
            }

            _showUnknown = args.Contains("--debug");
            bool gtsport = args.Contains("--gtsport");
            bool gt6 = args.Contains("--gt6");

            if (gtsport && gt6)
            {
                Console.WriteLine("Error: Both GT6 and GT Sport arguments are present.");
                return;
            }

            Console.WriteLine("Starting interface..");

            SimulatorInterfaceGameType type = SimulatorInterfaceGameType.GT7;
            if (gtsport)
                type = SimulatorInterfaceGameType.GTSport;
            else if (gt6)
                type = SimulatorInterfaceGameType.GT6;

            SimulatorInterfaceClient simInterface = new SimulatorInterfaceClient(args[0], type);
            simInterface.OnReceive += SimInterface_OnReceive;

            var cts = new CancellationTokenSource();

            // Cancel token from outside source to end simulator

            var task = simInterface.Start(cts.Token);

            try
            {
                await task;
            }
            catch (OperationCanceledException e)
            {
                Console.WriteLine($"Simulator Interface ending..{e.Message}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Errored during simulation: {e.Message}");
            }
            finally
            {
                // Important to clear up underlaying socket
                simInterface.Dispose();
            }
        }

        private static void SimInterface_OnReceive(SimulatorPacket packet)
        {
            using (StreamWriter sw = File.AppendText("data.txt")){

            // Print the packet contents to the console
            Console.SetCursorPosition(0, 0);
            packet.PrintPacket(_showUnknown);

            // Get the game type the packet was issued from
            SimulatorInterfaceGameType gameType = packet.GameType;

            // Check on flags for whether the simulation is active
            if (packet.Flags.HasFlag(SimulatorFlags.CarOnTrack) && !packet.Flags.HasFlag(SimulatorFlags.Paused) && !packet.Flags.HasFlag(SimulatorFlags.LoadingOrProcessing))
            {
//                double ser = 0.15 - (packet.EngineRPM / packet.MaxAlertRPM) / 10;
//                var device = new MAX7219();
//                var pwm = PwmChannel.Create(0, 0, 50, ser);
//                pwm.Start();
//                int speed = (int)Math.Floor(packet.MetersPerSecond * 3.6);
//                device.Write(speed.ToString());
                Vector3 data = new Vector3(packet.MetersPerSecond,packet.EngineRPM,packet.CurrentGear);
                Vector3 data2 = new Vector3(packet.Throttle, packet.Brake, packet.LapCount);
                Vector3 data3 = new Vector3(packet.TireFL_SusHeight, packet.TireFR_SusHeight, packet.TireRL_SusHeight);
                Vector3 data4 = new Vector3(packet.TireRR_SusHeight, packet.WheelFL_RevPerSecond, packet.WheelFR_RevPerSecond);
                Vector3 data5 = new Vector3(packet.WheelRL_RevPerSecond, packet.WheelRR_RevPerSecond, packet.TireFL_SurfaceTemperature);
                Vector3 data6 = new Vector3(packet.TireFR_SurfaceTemperature, packet.TireRL_SurfaceTemperature, packet.TireRR_SurfaceTemperature);
                Vector3 data7 = new Vector3(packet.TurboBoost, packet.OilPressure, packet.LapsInRace);
                Vector3 data8 = new Vector3(packet.MaxAlertRPM, packet.CalculatedMaxSpeed, packet.ClutchPedal);
                sw.WriteLine(packet.Position.ToString().Replace('−', '-'));
                sw.WriteLine(data.ToString().Replace('−', '-'));
                sw.WriteLine(data2.ToString().Replace('−', '-'));
                sw.WriteLine(data3.ToString().Replace('−', '-'));
                sw.WriteLine(data4.ToString().Replace('−', '-'));
                sw.WriteLine(data5.ToString().Replace('−', '-'));
                sw.WriteLine(data6.ToString().Replace('−', '-'));
                sw.WriteLine(data7.ToString().Replace('−', '-'));
                sw.WriteLine(data8.ToString().Replace('−', '-'));
                sw.WriteLine($"<{packet.LastLapTime:mm\\:ss\\.fff}, {packet.BestLapTime:mm\\:ss\\.fff}, {packet.MinAlertRPM}>");
                sw.WriteLine(packet.Velocity.ToString().Replace('−', '-'));
                sw.WriteLine(packet.Rotation.ToString().Replace('−', '-'));
                sw.WriteLine(packet.RoadPlane.ToString().Replace('−', '-'));
            }
            }
        }
    }
}
